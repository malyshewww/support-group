import backgroundForLanding from '../img/homepage/landing.svg';
import backgroundForMarket from '../img/homepage/market.svg';
import backgroundForShop from '../img/homepage/shop.svg';

export const backgrounds = { backgroundForLanding, backgroundForMarket, backgroundForShop }