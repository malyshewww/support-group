import calculatorMini from '../img/icons/min/calculator.mini.svg'
import puzzleMini from '../img/icons/min/puzzle.mini.svg'
import employeerMini from '../img/icons/min/employeer.mini.svg'
import macMini from '../img/icons/min/mac.mini.svg'
import windowMini from '../img/icons/min/window.mini.svg'
import phoneMini from '../img/icons/min/phone.mini.svg'
import startupMini from '../img/icons/min/startup.mini.svg'
import crmMini from '../img/icons/min/crm.mini.svg'
import discountMini from '../img/icons/min/discount.mini.svg'
import boxMini from '../img/icons/min/box.mini.svg'
import transportMini from '../img/icons/min/transport.mini.svg'
import mapMini from '../img/icons/min/map.mini.svg'

export const imgMini = { calculatorMini, puzzleMini, employeerMini, macMini, windowMini, phoneMini, startupMini, crmMini, discountMini, boxMini, transportMini, mapMini }