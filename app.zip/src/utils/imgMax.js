import calculator from '../img/icons/max/calculator.svg'
import puzzle from '../img/icons/max/puzzle.svg'
import employeer from '../img/icons/max/employeer.svg'
import mac from '../img/icons/max/mac.svg'
import window from '../img/icons/max/window.svg'
import phone from '../img/icons/max/phone.svg'
import startup from '../img/icons/max/startup.svg'
import crm from '../img/icons/max/crm.svg'
import discount from '../img/icons/max/discount.svg'
import box from '../img/icons/max/box.svg'
import transport from '../img/icons/max/transport.svg'
import map from '../img/icons/max/map.svg'

export const imgMax = { calculator, puzzle, employeer, mac, window, phone, startup, crm, discount, box, transport, map }